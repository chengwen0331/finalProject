<?php
if (!isset($_POST)) {
    $response = array('status' => 'failed', 'data' => null);
    sendJsonResponse($response);
    die();
}

include_once("dbconnect.php");

if (isset($_POST['buyerid'])){
	$buyerid = $_POST['buyerid'];	
	$sqlorder = "SELECT * FROM `apps_orders` WHERE buyer_id = '$buyerid'";
}
//`order_id`, `order_bill`, `order_paid`, `buyer_id`, `seller_id`, `order_date`, `order_status`

$result = $conn->query($sqlorder);
if ($result->num_rows > 0) {
    $orderitems["orders"] = array();
	while ($row = $result->fetch_assoc()) {
        $orderlist = array();
        $orderlist['order_id'] = $row['order_id'];
        $orderlist['order_bill'] = $row['order_bill'];
        $orderlist['order_paid'] = $row['order_paid'];
        $orderlist['buyer_id'] = $row['buyer_id'];
        $orderlist['seller_id'] = $row['seller_id'];
        $orderlist['order_date'] = $row['order_date'];
        $orderlist['order_status'] = $row['order_status'];
         $orderlist['order_lat'] = $row['order_lat'];
          $orderlist['order_lng'] = $row['order_lng'];
          $orderlist['order_state'] = $row['order_state'];
          $orderlist['order_locality'] = $row['order_locality'];
        array_push($orderitems["orders"] ,$orderlist);
    }
    $response = array('status' => 'success', 'data' => $orderitems);
    sendJsonResponse($response);
}else{
     $response = array('status' => 'failed', 'data' => null);
    sendJsonResponse($response);
}
function sendJsonResponse($sentArray)
{
    header('Content-Type: application/json');
    echo json_encode($sentArray);
}